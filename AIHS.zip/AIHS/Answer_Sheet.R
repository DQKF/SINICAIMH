#Answers 2021/11/26

library(readr)#loading test06.csv
test06 <- read_csv("~/Documents/AIHS/AIHS/test06.csv")
View(test06)
nrow(test06)
ncol(test06)
test06<-test06[,-c(1,3)]#刪除不需要的column
test06<-test06[-c(20),]#刪除不需要的row
colnames(test06)[3]<-"pub_date" #更改column名稱與test05一致
colnames(test06)[4]<-"journal"  #更改column名稱與test05一致

test06[c("5","journal")]<-"期刊" #將NA取代為"期刊"
test06<-test06[!duplicated(test06$title),] #刪除重複的docs
test06$pub_sta<-"PRC" #增加test05有，但test06還沒有的column
View(test06)
test06<-test06[c("title", "author", "source","pub_date","journal", "abstract", "pub_sta")]
#重新排列column使其column的排列順序與test05一致
View(test06)

test07<-rbind(test05, test06)#合併兩個檔案，如合併不成，請檢查
#a.column name的順序是否仍不一致？
#b.column的數目是否相同？ncol(test05), ncol(test06)
#c.日期格式是否都調整為Date格式？需要檢查屬性。
class(test05$pub_date)
class(test06$pub_date)
#如果出現的屬性為character，請立刻改為date格式。
test05$pub_date<-as.Date(test05$pub_date)#改為date格式



#如合併成功，請接著繼續處理

test07<-test07[order(test07$pub_date),] #重新編排日期次序
test07<-test07[!duplicated(test07$title),] #刪除重複的docs
test07$ID<-seq.int(nrow(test07))#給予serial ID編號
test07<-test07[c("ID", "title", "author", "pub_date","source","journal", "abstract","pub_sta")] #重新排列column的次序
View(test07)
write.csv(test07, "test07.csv")