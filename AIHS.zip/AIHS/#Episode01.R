#Lesson 1
## 1_1 設定路徑：你的工作區在哪裡？ setting yr working directory.

setwd("")
setwd("/Users/georgenee/Documents/AIHS/AIHS")

#setting via control table
#Rstudio>Session>Set Working Directory>Choose Directory

#getting yr working directory.
getwd()
##[1] "/Users/georgenee/Documents/AIHS/AIHS"


# 1_2 設定使用語言 human language use in your data

# for windows
 #English
 Sys.setlocale(category = "LC_ALL", locale = "UTF-8")
 #繁體中文
 Sys.setlocale(category = "LC_ALL", locale = "zh_TW.UTF-8")#避免中文亂碼
 #簡體中文
 Sys.setlocale(category = "LC_ALL", locale = "zh_CN.UTF-8")
 
 
# for MAC
 #English
 Sys.setlocale(category = "LC_ALL", locale = "en_US.UTF-8")
 
 #繁體中文
 Sys.setlocale(category = "LC_ALL", locale = "zh_TW.UTF-8") #避免中文亂碼
 #簡體中文
 
 Sys.setlocale(category = "LC_ALL", locale = "zh_CN.UTF-8")

#查看R當中的語系 Make sure which human language is employing in this R project.
Sys.getlocale()

[1] "zh_TW.UTF-8/zh_TW.UTF-8/zh_TW.UTF-8/C/zh_TW.UTF-8/zh_TW.UTF-8"


#1_3 查看R當中的語系分佈 Sorting the distribution of human languages use in R & expressions.
>library(stringr)
>locales <- system("locale -a", intern = TRUE)
>unique(str_split_fixed(locales, "\\.", 2)[, 1])

 [1] "en_NZ" "nl_NL" "pt_BR" "fr_CH" "eu_ES" "en_US" "af_ZA" "bg_BG" "cs_CZ" "fi_FI" "zh_CN"
[12] "sk_SK" "nl_BE" "fr_BE" "de_CH" "de_DE" "am_ET" "zh_HK" "be_BY" "uk_UA" "pt_PT" "en_AU"
[23] "kk_KZ" "de_AT" "hr_HR" "fr_FR" "ro_RO" "da_DK" "ca_ES" "sv_SE" "fr_CA" "it_CH" "hu_HU"
[34] "et_EE" "he_IL" "ko_KR" "it_IT" "ru_RU" "zh_TW" "no_NO" "en_CA" "sl_SI" "pl_PL" "ja_JP"
[45] "sr_YU" "en_GB" "is_IS" "hy_AM" "es_ES" "el_GR" "lt_LT" "tr_TR" "en_IE" "hi_IN" "C"    
[56] "POSIX"



##1_4 Loading data

#1_4_1 Loading EXCEL
library(readxl)
install.packages("readxl")

# 讀取 Excel 檔案的「1st_sheet」; loading "1st_sheet" from the document.
test01 <- read_excel("test01.xlsx", 
	col_names = TRUE, sheet = "1st_sheet")
View(Test01)


# 讀取 Excel 檔案的「2nd_sheet」;loading "2nd_sheet" from the document.
test02 <- read_excel("test01.xlsx", 
	col_names = TRUE, sheet = "2nd_sheet")
View(Test02)

#1_4_2 Loading .csv format file.
test03 <- read_csv("test03.csv")
View(test03)


#1_4_3 Loading .txt format file
textRR <- read.table('textRR.txt',sep = '\t',header = FALSE).
View(textA)

#1_4_4 Loading from the Web

url <- "http://www.econ.sinica.edu.tw/UpFiles/2013090214141704234/Periodicals_Pdf2013090215154369017/TEFP521-4.pdf"
  #find out the page for download
destfile <- "myfile.pdf" # write in the file name.
download.file(url, destfile, mode="wb") #push the "download"下載 button


# 1_4_4 Loading a FOLDER
 #結合與分離一個folder內的.txt files
  #結合 MERGE. merge all .txt docs in a folder.
install.packages("readtext")
library(readtext)
sb<-readtext("/users/georgenee/Documents/AIHS/AIHS/testtt/*txt")
View(sb)

  #分割 SPLIT. split one merged file into multiple docs. 
sb$ID<-seq.int(nrow(sb)) #建立順序編號, create serial numbers as ID.
temp011 <- split(sb$text, sb$ID)
         #擷取內容與順序編號，順序編號一定要在後面，
          #這樣才能通過新的檔名將先前sb內各文件的先後次序取得一致。
Map(function(x, y) writeLines(x, paste0(y, '.txt')), temp011, names(temp011))

View(temp011)

#1_5 Create a data.frme
#將檔案內容劃歸為獨立的column
##抽取在一個folder中的.txt第一行
#工作項目folder: testtt, 裡面有3個檔案：textA, textB, textC
#必須注意的是，這一行的字元「不能有」空白
setwd("/users/georgenee/Documents/AIHS/AIHS/testtt")  
con <- file("textA.txt","r")
first_line <- readLines(con,n=1)
close(con)
cat(first_line,file="first_line.txt")

#擷取文件內的項目，使之成為data.frame
direc <- setwd("/users/georgenee/Documents/AIHS/AIHS/testtt")  
files <- list.files("/users/georgenee/Documents/AIHS/AIHS/testtt")
View(files)
num_files <- length(files)
View(num_files)
line <- list()
for (i in 1:num_files) {
  line <- list(line, read.table(files[[i]], header = F, nrow = 4))#只取1-4行,4個變項
}
print(line)
df <- data.frame(matrix(unlist(line), ncol = 4, byrow = T))#因為取4個變項，所以給予4個column
View(df)

#給予data.frame 上的column name
colnames(df)[1]<-"title"
colnames(df)[2]<-"date"
colnames(df)[3]<-"content"
colnames(df)[4]<-"occasion"
View(df)

class(df$title)
class(df$date)
class(df$content)
class(df$occasion)

#轉化date為時間格式
df$date<-as.Date(df$date)
class(df$date)

#給予順序編號
df$ID<-seq.int(nrow(df))



#將ID的 column放在第一個 column
df<-df[c("ID", "title", "date", "content", "occasion")]
View(df)


#資料（column）的變數屬性


#factor: categorical variables

sex <- factor(c("female", "male", "trans"))
levels(sex)#levels()查看變數共有幾種;
              #use "levels()" to check the exact number of items in the column. 
levels(df$occasion) #NOTICE! column "occasion"'s attribute has not changed!  
class(df$occasion)
df$occasion<-as.factor(df$occasion) # transform it to class "factor"


#integer：as integer 整數. Ex: YEAR 年, Pages 頁數, Paragraphs....

#numeric: numbers with with decimal point 
#length, weights, scores....

#date: as date
 # a little bit complex to handle & we'll discuss the issue later on. 



## tip 1. Too many files in the storage? just remove files of no use. 
rm(gender, df, Test01, Test02, Test03)
### tip 2. SAVE them before the tea breaks!!  
# NOT RUN until U fill in.  save.images("請在這裡填入您命名的檔名.RData")
# NOT RUN until U fiil in.  save.images("nameofthefile.RData")
