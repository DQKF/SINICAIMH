#Episode02
##2_1 Dealing with Strings & data.frame, 處理strings & dataframe
### file in use: "text05.csv", 採用檔案text05.csv
setwd("/users/georgenee/Documents/AIHS/AIHS")
library(readr)
test05 <- read_csv("~/Documents/AIHS/AIHS/test05.csv")
View(test05)

##tidy, 整理資料
test05<-test05[-c(9),]#delete row "9"
View(test05)

test05<-test05[,-c(7)]#delete column "content"
View(test05)

test05[c("8", "journal")]<-"期刊"  #fill in value to replace "na".
View(test05)

#extract rows 1,4,5
Ntest05<-test05[c(1,4:5),]
View(Ntest05)


#extract colunms 2, 3,4
NNtest05<-test05[,c(2:4)]
View(NNtest05)

#加入新的資料 add new files
test05<-rbind(test05,Ntest05)

#加入新的欄位 add new columns
##create new columns

test05$pub_sta<-"PRC"
View(test05)

#找出重複資料 sort out duplicated docs.
Dtest05<-test05[duplicated(test05$title),]
View(Dtest05)


#刪除重複的資料 remove diplicated docs.
test05<-test05[!duplicated(test05$title),] 
#notice! exclamation mark "!" = negation
View(test05)



#ordering 排列順序
#Taking "pub_date" as an example
test05<-test05[order(test05$pub_date),]
Rtest05<-test05[rev(order(test05$pub_date)),] #reversed
View(Rtest05)

#其他重要功能

nrow(test05) #幾個row? How many rows?
ncol(test05) #有幾個column? How many columns?
colnames(test05)[column serial K]<-""  #將第Ｘ個column重新命名 
                       #Changing the name of one specific column in serial K.
#NOT RUN  colnames(test05)[3]<-"nirvana"
colnames(test05) <- c("x","Y", ""........)

nchar(test05$title) #在title這個column分別有幾個字？
                    #How many words in column "title" respectively?



#Task
##combine test05 & test06 into test07 with 8 columns & ? rows

