#Episode03
#3_1Keep working on strings!
View(test07)
test08<-test07[,c(1:4)]
View(test08)
#"grep" function
##Which document contain "馬克思" on its title?
t08Marx<-test08[grep("馬克思",  test08$title) ,]
View(t08Marx)

#"gsub"function
#擷取包含「習近平總書記」這個詞彙的documents
t08X<-test08[grep("習近平總書記",  test08$abstract) ,]
View(t08X)

test08$abstract_01<-test08$abstract 
#copy column "abstract" to another new column "abstract_01"
test08$abstract_01<-gsub("習近平總書記","習近平",  test08$abstract_01)
##將「習近平總書記」改為「習近平總書記」
test08$abstract_01<-gsub("中華民族的偉大復興","中華民族的偉大復興",  test08$abstract_01)
##將「中華民族的偉大復興」改為「中華民族的偉大復興」
#replace "from","to"
View(test08)



#"split" function 字的擷取
install.packages("stringr")
library(stringr)
View(test08)
test08$surname<-str_sub(test08$author, start = 1, end = 1)
test08$first_name<-str_sub(test08$author, start = 2, end = 3)
test08$year<-str_sub(test08$pub_date, start = 1, end = 4)


#"paste" function 字串黏貼組合

#paste()
test08$author3<-paste(test08$surname, test08$first_name, sep="///")
View(test08)
test08$abstract<-test07$abstract
#str_c() func as "paste" in R Package "stringr"
test08$author1<-str_c(test08$surname,"", test08$first_name)
test08$author2<-str_c(test08$surname,"-", test08$first_name)




#3_2 Time Format
##week format
install.packages("ISOweek")
library(ISOweek)
install.packages("lubridate")
library(lubridate)

#ISOweek sets Monday as the 1st day of the week.

#運行lubridate package 分別取得取得week & year 格式
#acquire "week"
test08$isoweek <-  lubridate::isoweek(test08$pub_date)
#指定套件的函數::指定套件的函數，直接運行的意思。
class(test08$isoweek)
#"numeric"

##acquire "year"
test08$isoyear <- lubridate::isoyear(test08$pub_date)
class(test08$isoyear)
#"numeric"


#運行ISOweek package 取得yyyy-week 格式

x<-test08$pub_date
xx<-data.frame(date = x, week = ISOweek(x))
View(xx)
class(xx$week)
#[1] "character"
test08$ISOYW<-xx$week

#Package "tsibble", easy to learn!
install.packages("tsibble")
library(tsibble)
##year-week
yearweek(test08$pub_date)
test08$tsibleYW<-yearweek(test08$pub_date)
class(test08$tsibleYW)
View(test08)
##year-month
test08$tsibbleYM<-yearmonth(test08$pub_date)
class(test08$tsibbleYM)
##year=quarter
test08$tsibbleYQ<-yearmonth(test08$pub_date)
class(test08$tsibbleYQ)


#3.3Parsing 分詞
#parse column "abstract_01" in test08
#user's own dictionary and stopwords list are needed
#now we have two sets of simple user's dictionaries.
#users="AIMH_user.txt", stopwords="AIMH_STP.txt"
#NOTICE! save these dictionary-related files in jiebaRD.
  ##directory:"/Library/Frameworks/R.framework/Versions/3.6/Resources/library/jiebaRD/dict"

#R packages required for parsing: jiebaR, jiebaRD, tm, NLP

library(jiebaRD)
library(jiebaR)
library(NLP)
library(tm)
setwd("/Library/Frameworks/R.framework/Versions/3.6/Resources/library/jiebaRD/dict")
cutter <- worker(type="mix", dict = "jieba.dict.utf8", stop_word = "AIMH_STP.txt", user = "AIMH_user.txt")
#cutter==分詞, dict=jiebaRD內建辭典，其餘兩項為作者自定義辭典。
 ##需檢查你的jiebaRD內建詞典是簡體中文還是繁體中文。
View(test08)


test08$text<-paste(test08$abstract_01,"uuu")
    #在每個摘要後面貼上"uuu"，最為之後分割的記號。
contentX8<-as.character(test08$text)
segtextX8 <- segment(contentX8, cutter)#進行分詞
segtextpasteX8 <- paste(segtextX8, collapse = " ")
setwd("/users/georgenee/Documents/AIHS/AIHS")#轉回原先的工作目錄
write(segtextpasteX8,"X8JP.txt")

#利用sublime text3 開啟X8JP.txt，開啟後用分行符號\n 取代uuu。
#在第一行鍵入"newc"，這是作為分詞後的column's name。
#sublime text3➡File➡save with encoding➡utf-8"
X8TTT <- read.table('X8JP.txt',sep = '\t',header = TRUE)#另存新檔
nrow(X8TTT)
nrow(test08)#兩者數目必須一致
View(test08)
test08<-cbind(test08, X8TTT)#將分詞後的結果與原先的檔案通過cbind函數貼在一起

#Frequency 統計詞頻
##之後採用R Package "quanteda"進行各項操作
##分詞之後的稱為token 單詞。單詞與字不同。
#計算詞頻

library(quanteda)
library(quanteda.textstats)
library(data.table)
toks <- tokens(test08$newc, what = "fastestword") 
                                  #"fastestword"表示完全不更動分詞結果
dfmat_test08<- dfm(toks)#dfm=document feature matrix。
                        ##表示在這個矩陣中，每一個文件的單詞(token=feature)的分布狀態
View(dfmat_test08)
Freq_test08 <- as.data.table(textstat_frequency(dfmat_test08))
View(Freq_test08)

Freq_test08 <- Freq_test08[nchar(Freq_test08$feature ) > 1, ]#將切割出來只有一個字的都先刪除
View(Freq_test08)
nrow(Freq_test08)
Freq_test08_2 <- Freq_test08[(Freq_test08$frequency ) > 3, ] 
View(Freq_test08_2 )
write.csv(Freq_test08, "Freq_test08.csv")


#write to EXCEL
install.packages("writexl")
library("writexl")
write_xlsx(the dataframe name,"path to store the Excel file/file name.xlsx")
write_xlsx(Freq_test08,"/users/georgenee/Documents/AIHS/AIHS/Freq_test08.xlsx")







#3.4 KWIC
#擷取"百年未有之大變局"前後共10個詞。
tokss <- tokens(test08$newc, what="fastestword")
KWICT8<-kwic(tokss, pattern = "百年未有之大變局", valuetype = "glob", window = 10)
#patter=關鍵詞
#valuetype=資料種類。通常使用詞典的，採用"glob"
#window=前後Ｎ個字元

View(KWICT8)
KWICT8$prekeypost<-paste(KWICT8$pre,KWICT8$keyword, KWICT8$post, sep=" ")
#將KWICT8這個檔案中的3個column進行合併。注意，合併時必須空一個space，所以sep=" "
KWICT8<-tibble(KWICT8)
#tibble是類似於data.frame形式的格式，比較靈活運用。
View(KWICT8)


##3.5 Visualization I
##利用quanteda繪製簡單的社群網絡圖
install.packages("quanteda.textmodels")
library(quanteda.textmodels)

install.packages("quanteda.textplots")
library(quanteda.textplots)

install.packages("showtext")
library(showtext)



toks_news <- tokens(KWICT8$prekeypost, what = "fastestword")
dfmat_news <- dfm(toks_news)
dfmat_news <- dfm_remove(dfmat_news, min_nchar = 2,  
                         pattern = c(stopwords("en"), "*-time", "updated-*", "gmt", "bst"))
dfmat_news <- dfm_trim(dfmat_news, min_termfreq = 2)
topfeatures(dfmat_news)
ndoc(dfmat_news)
nfeat(dfmat_news)
fcmat_news <- fcm(dfmat_news)
dim(fcmat_news)
write.csv(fcmat_news, "fsmat_news.csv")
View(fcmat_news)




ggplot(Freq_test08, aes(x = feature, y = frequency)) +
  geom_point() + 
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

install.packages("ggplot2")
library(ggplot2)

set.seed(01673)
feat <- names(topfeatures(fcmat_news, 52))
size <- log(colSums(dfm_select(dfmat_news, feat, selection = "keep")))

#圖一
fcm_select(fcmat_news, pattern = feat) %>%
  textplot_network(min_freq = 0.9, omit_isolated=TRUE, edge_color = "#afe8f0", vertex_color = "grey", vertex_labelcolor ="black",edge_alpha = 0.8)

#圖二              
set.seed(144)
textplot_network(fcmat_news, min_freq = 0.9, vertex_size = size / max(size) * 5, family= "宋體-簡")
View(fcmat_news)

#圖三
set.seed(01673)
fcm_select(fcmat_news, pattern = feat) %>%
  textplot_network(min_freq = 0.8,omit_isolated=TRUE, edge_color = "#5388bd", vertex_color = "#4D4D4D", edge_alpha = 0.8 )
showtext_auto()

#圖四 稀疏矩陣dgTMatrix
sim <- textstat_proxy(dfmat_news, margin = "features")
textplot_network(quanteda:::as.fcm(as(sim, "dgTMatrix")), min_freq = 0.9)






